﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MatisLigia_ProiectExamen.Migrations
{
    public partial class CarPrice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
