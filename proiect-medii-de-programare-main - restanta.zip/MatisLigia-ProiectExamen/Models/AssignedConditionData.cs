﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MatisLigia_ProiectExamen.Models
{
    public class AssignedConditionData
    {
        public int ConditionID { get; set; }
        public string Name { get; set; }
        public bool Assigned { get; set; }
    }
}
